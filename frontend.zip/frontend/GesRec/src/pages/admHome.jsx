import React from "react";
import Header from "../Header";
import { Link } from "react-router-dom";
    const people = [
  {
    name: 'Leslie Alexander',
    role: 'Co-Founder / CEO',
    imageUrl:
      'https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80',
  },
  // More people...
]

export default function admHome() {
  return (
    <div >
     <Header/>
    <div className=" py-24 sm:py-32 relative bg-no-repeat bg-cover h-full bg-center bg-full 
       bg-[url('https://img.freepik.com/photos-gratuite/entreprise-concept-entrevue-emploi_1421-77.jpg?w=996&t=st=1697183418~exp=1697184018~hmac=b36a205278c40a6207578ff5e678209b83d876b530844798d6da4cc36438fe50">
    
      </div>
            </div>
            
          );
          }